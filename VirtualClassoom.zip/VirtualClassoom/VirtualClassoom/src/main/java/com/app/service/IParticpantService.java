package com.app.service;

import java.util.List;

import com.app.pojos.Particpant;

public interface IParticpantService  {

	Particpant registerParticpant(Particpant v);

	List<Particpant> getAllUser(String email, String password);

	Particpant authenticateUser(String email, String password);

}
