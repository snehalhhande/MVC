package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IParticpantDao;
import com.app.pojos.Particpant;

@Service
@Transactional
public class ParticpantServiceImpl implements   IParticpantService{
@Autowired
	private IParticpantDao particpantDao;
	@Override
	public  Particpant registerParticpant(Particpant p) {
	
		return  particpantDao.save(p);
	}
	@Override
	public Particpant authenticateUser(String email, String password) {
		// TODO Auto-generated method stub
		return particpantDao.getUser(email,password);
	}
	@Override
	public List<Particpant> getAllUser(String email, String password) {
		
		return particpantDao.findAll();
	}

}
