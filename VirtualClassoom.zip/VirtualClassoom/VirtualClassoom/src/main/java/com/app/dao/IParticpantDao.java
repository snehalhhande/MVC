package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojos.Particpant;

public interface IParticpantDao extends JpaRepository<Particpant, Integer> {
	@Query(value = "select p from Particpant p where p.email=:email and p.password=:password")
	Particpant getUser(String email, String password);

}
