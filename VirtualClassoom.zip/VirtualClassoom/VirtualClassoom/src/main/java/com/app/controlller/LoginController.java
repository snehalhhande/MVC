package com.app.controlller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Particpant;
import com.app.service.IParticpantService;
@Controller
@RequestMapping("/particpant")
public class LoginController {
	@Autowired
	private IParticpantService particpantService;
	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in login method");

		return "/login";
	}

//add a request handling method to process the form 
//display email and pwd
	@PostMapping("/login")
	public String processLogin(@RequestParam String email, @RequestParam String password, Model map, HttpSession session) {
		System.out.println("Request parameters are......");
		System.out.println("Emailid :" + email);
		System.out.println("Password :" + password);
		// invoke service's method for validation

		try {
			Particpant validatedUser = particpantService.authenticateUser(email, password);
			System.out.println("Login Successfull....");
			//Login Successfull
			//add a message Admin/Vendor login successful
			//session.setAttribute("message", );
			List<Particpant> allUser = particpantService.getAllUser(email, password);
			session.setAttribute("user_details", validatedUser);
			session.setAttribute("all_user_details", allUser);
		
			return "redirect:/particpant/details";
		} catch (RuntimeException e) {
			// failed login
			// add error msg the model attribute
			map.addAttribute("message", "Invalid login , please Retry");
			// forword the client to login page

			return "/user/login";
		}
		
	}
	@GetMapping("/details")
	public String showLoginDetail() {
		System.out.println("in login method");

		return "/details";
	}
}