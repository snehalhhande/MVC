package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Particpant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer uId;
	@Column(length = 20, nullable = false)
	private String name;
	@Column(length = 20, nullable = false, unique = true)
	private String email;
	@Column(length = 10, nullable = false)
	private String password;
	@Column(length = 10, nullable = false)
	private String batch;
	private int rollNum;

	public Particpant() {
		// TODO Auto-generated constructor stub
	}

	
	public Particpant(String name, String email, String password, String batch, int rollNum) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.batch = batch;
		this.rollNum = rollNum;
	}


	public Integer getuId() {
		return uId;
	}


	public void setuId(Integer uId) {
		this.uId = uId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getBatch() {
		return batch;
	}


	public void setBatch(String batch) {
		this.batch = batch;
	}


	public int getRollNum() {
		return rollNum;
	}


	public void setRollNum(int rollNum) {
		this.rollNum = rollNum;
	}


	@Override
	public String toString() {
		return "Particpant [uId=" + uId + ", name=" + name + ", email=" + email + ", batch=" + batch + ", rollNum="
				+ rollNum + "]";
	}

}
