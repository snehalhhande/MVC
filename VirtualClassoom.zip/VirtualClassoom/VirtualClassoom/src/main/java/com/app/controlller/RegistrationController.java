package com.app.controlller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Particpant;
import com.app.service.IParticpantService;

@Controller
@RequestMapping("/particpant")
public class RegistrationController {
	@Autowired
	private IParticpantService particpantService;

	@GetMapping("/register")
	public String showRegPage() {
		return "/register";
	}

	@PostMapping("/register")
	public String processParticpantRegisterationForm(@RequestParam String name, @RequestParam String email,
			@RequestParam String password, @RequestParam String batch, @RequestParam int rollNum) {
		Particpant particpant = new Particpant(name, email, password, batch, rollNum);
		System.out.println(particpant);
		particpantService.registerParticpant(particpant);

		return "login";

	}

}